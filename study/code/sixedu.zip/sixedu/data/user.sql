username,password,age,sex
shineyork,123456,18,男
